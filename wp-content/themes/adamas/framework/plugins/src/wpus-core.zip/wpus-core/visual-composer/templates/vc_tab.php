<?php
/**
 * Shortcode: Tab
 * 
 * @package Adamas
 * @author  WP Uber Studio
 * @version 1.0
 */

global $adamas_sc_tabs;
$adamas_sc_tabs[]  = array( 'atts' => $atts, 'content' => $content );